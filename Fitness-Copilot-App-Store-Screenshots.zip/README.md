# Fitness Copilot App Store screenshots

This package contains 3 iPhone portrait screenshots for each App Store localization:

- `tr-TR` — Turkish
- `en-US` — English (United States)
- `es-ES` — Spanish (Spain)
- `pt-BR` — Portuguese (Brazil)
- `fr-FR` — French
- `de-DE` — German
- `ar` — Arabic

Each image is 1290 × 2796 pixels, JPEG, with no transparency. The three screens are Home, Exercises, and Muscle Atlas preview. The images show the product UI and a free, interactive 3D anatomy preview; selecting muscles and the full atlas are identified as PRO features.

App Store Connect shows localized screenshots based on the store localization available to each customer. This is separate from the app's language selection, which follows the device's preferred language on first launch and then respects the user's saved choice.
